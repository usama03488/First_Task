using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotator : MonoBehaviour
{
    private Vector3 scale;
  
 
    private float x, y, z;
    private bool Isrotate;
    // Start is called before the first frame update
    void Start()
    {
        scale = new Vector3(-0.01f, -0.01f, -0.01f);
        x = 0.01f;y=0.01f;z = 0.01f;
        scale=transform.localScale;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
          transform.localScale += scale;
            Isrotate = true;
        }
        else if(Input.GetKeyDown(KeyCode.LeftArrow)|| Input.GetKeyDown(KeyCode.RightArrow))
        {
            transform.Rotate(x+=1,y+=1,z+=1);
            Isrotate = true;
        }
        else if(Isrotate)
        {
            x = x - 0.01f;
            y = y - 0.01f;
            z = z - 0.01f;
            transform.Rotate(-x, -y, -z);
            transform.localScale -= scale;
        }

    }
}
